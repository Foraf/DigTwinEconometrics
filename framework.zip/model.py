"""
Digital Twin Model for Lika-Senj (AR + NFT Interventions)
Author: Raffaella Folgieri
Date: 25-04-2025

This script implements:
1. Synthetic data generation for farmers and tourists
2. Geospatial data download for Lika-Senj
3. Agent-based simulation of NFT/AR adoption
4. System dynamics for macroeconomic impacts
5. Geospatial optimization of AR kiosk placement
"""

# =====================
# 1. SETUP & DEPENDENCIES
# =====================
import pandas as pd
import numpy as np
import geopandas as gpd
import osmnx as ox
import mesa
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from pulp import LpProblem, LpMinimize, LpVariable, lpSum
import networkx as nx
from faker import Faker
import random
from shapely.geometry import Point

print("All packages imported successfully!")

# =====================
# 2. DATA GENERATION
# =====================
def generate_synthetic_data(num_farmers=100, num_tourists=500):
    """Generate synthetic datasets for farmers and tourists"""
    fake = Faker()
    
    # Farmer data (NFT adoption potential)
    farmers = pd.DataFrame({
        'id': range(num_farmers),
        'income': np.random.normal(1500, 300, num_farmers).clip(800, 3000),
        'digital_literacy': np.random.beta(2, 3, num_farmers),
        'broadband_access': np.random.choice([0, 1], num_farmers, p=[0.3, 0.7]),
        'location': [fake.local_latlng(country_code='HR')[:2] for _ in range(num_farmers)]
    })
    
    # Tourist data (AR engagement potential)
    seasons = ['winter']*100 + ['spring']*150 + ['summer']*200 + ['fall']*150
    tourists = pd.DataFrame({
        'id': range(num_tourists),
        'season': random.choices(seasons, k=num_tourists),
        'budget': np.random.lognormal(6, 0.3, num_tourists).clip(50, 500),
        'tech_savviness': np.random.beta(3, 2, num_tourists)
    })
    
    return farmers, tourists

# =====================
# 3. GEOSPATIAL DATA
# =====================
def download_lika_geodata():
    """Download OpenStreetMap data for Lika-Senj County"""
    print("Downloading geospatial data for Lika-Senj...")
    
    # Get administrative boundary
    lika = ox.geocode_to_gdf("Lika-Senj County, Croatia")
    
    # Get points of interest (cultural heritage sites)
    tags = {'tourism': ['attraction', 'museum', 'viewpoint'],
            'historic': ['monument', 'castle']}
    pois = ox.geometries_from_place('Lika-Senj County, Croatia', tags)
    
    # Get road network for accessibility analysis
    G = ox.graph_from_place('Lika-Senj County, Croatia', network_type='drive')
    
    return lika, pois, G

# =====================
# 4. AGENT-BASED MODEL
# =====================
class FarmerAgent(mesa.Agent):
    """Agent representing farmers adopting NFTs"""
    def __init__(self, unique_id, model, income, digital_literacy, broadband):
        super().__init__(unique_id, model)
        self.income = income
        self.digital_literacy = digital_literacy
        self.broadband = broadband
        self.adopted_nft = False
        
    def step(self):
        # Adoption probability based on income, literacy, and peer influence
        neighbors = self.model.grid.get_neighbors(self.pos, include_center=False)
        peer_adoption = sum([n.adopted_nft for n in neighbors]) / (len(neighbors) + 1)
        
        adoption_prob = 0.3 * (self.income > 1200) + \
                       0.4 * self.digital_literacy + \
                       0.3 * peer_adoption + \
                       0.2 * self.broadband
        
        if random.random() < adoption_prob:
            self.adopted_nft = True

class TourismModel(mesa.Model):
    """Main model container"""
    def __init__(self, farmers_df):
        super().__init__()
        self.grid = mesa.space.MultiGrid(20, 20, True)
        self.schedule = mesa.time.RandomActivation(self)
        
        # Create farmer agents
        for idx, farmer in farmers_df.iterrows():
            agent = FarmerAgent(idx, self, farmer['income'], 
                              farmer['digital_literacy'], 
                              farmer['broadband_access'])
            self.grid.place_agent(agent, (random.randrange(20), random.randrange(20))
            self.schedule.add(agent)
            
    def step(self):
        self.schedule.step()

# =====================
# 5. SYSTEM DYNAMICS
# =====================
def macro_feedback(y, t, params):
    """Differential equations for macroeconomic feedback"""
    gdp, tourism = y
    alpha, delta, gamma = params
    
    dgdp_dt = alpha * tourism - 0.05 * gdp
    dtourism_dt = gamma * (100 - tourism) - delta * tourism
    
    return [dgdp_dt, dtourism_dt]

# =====================
# 6. GEOSPATIAL OPTIMIZATION
# =====================
def optimize_ar_placement(pois, budget=500000):
    """Optimize AR kiosk placement using p-median"""
    # Create distance matrix between POIs
    n = len(pois)
    distances = np.zeros((n, n))
    
    for i in range(n):
        for j in range(n):
            distances[i,j] = pois.geometry[i].distance(pois.geometry[j])
    
    # Set up optimization problem
    prob = LpProblem("AR_Kiosk_Placement", LpMinimize)
    
    # Decision variables
    x = LpVariable.dicts("x", range(n), cat='Binary')  # 1 if selected
    y = LpVariable.dicts("y", [(i,j) for i in range(n) for j in range(n)], cat='Binary')
    
    # Objective: minimize total distance
    prob += lpSum(distances[i][j] * y[(i,j)] for i in range(n) for j in range(n))
    
    # Constraints
    prob += lpSum(x[i] for i in range(n)) <= budget/100000  # Budget constraint
    for j in range(n):
        prob += lpSum(y[(i,j)] for i in range(n)) == 1  # Each POI served
        for i in range(n):
            prob += y[(i,j)] <= x[i]  # Can only be served if kiosk exists
    
    prob.solve()
    selected = [i for i in range(n) if x[i].varValue > 0.9]
    
    return selected

# =====================
# 7. MAIN EXECUTION
# =====================
if __name__ == "__main__":
    print("=== Digital Twin Simulation for Lika-Senj ===")
    
    # Generate data
    farmers, tourists = generate_synthetic_data()
    lika, pois, road_network = download_lika_geodata()
    
    # Run ABM simulation
    print("\nRunning NFT adoption simulation...")
    model = TourismModel(farmers)
    for _ in range(10):  # 10 time steps
        model.step()
    
    # Calculate adoption rate
    adoption_rate = sum(agent.adopted_nft for agent in model.schedule.agents) / len(model.schedule.agents)
    print(f"Final NFT adoption rate: {adoption_rate:.1%}")
    
    # Run system dynamics
    print("\nSimulating macroeconomic impacts...")
    params = (0.2, 0.1, 0.15)  # alpha, delta, gamma
    y0 = [500, 30]  # Initial GDP and tourism
    t = np.linspace(0, 5, 100)  # 5 years
    solution = odeint(macro_feedback, y0, t, args=(params,))
    
    # Optimize AR placement
    print("\nOptimizing AR kiosk placement...")
    selected_pois = optimize_ar_placement(pois)
    print(f"Selected {len(selected_pois)} locations for AR kiosks")
    
    # Visualization
    fig, ax = plt.subplots(figsize=(10, 6))
    lika.plot(ax=ax, color='lightgrey')
    pois.plot(ax=ax, color='blue', markersize=5)
    pois.iloc[selected_pois].plot(ax=ax, color='red', markersize=50, alpha=0.5)
    plt.title("Optimized AR Kiosk Placement in Lika-Senj")
    plt.savefig('ar_kiosk_placement.png')
    print("Visualization saved to 'ar_kiosk_placement.png'")
    
    print("\n=== Simulation complete ===")