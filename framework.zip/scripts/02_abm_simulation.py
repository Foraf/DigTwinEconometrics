# scripts/02_abm_simulation.py
import pandas as pd
import os
import yaml
import random
import importlib.util
import mesa
from mesa import Agent, Model
from mesa.space import MultiGrid
from mesa.time import RandomActivation
from mesa.datacollection import DataCollector  # Import specifico mancante
from shapely.geometry import Point

# Configurazione dell'import dinamico
spec = importlib.util.spec_from_file_location(
    "data_gen",
    os.path.join(os.path.dirname(__file__), "01_data_generation.py")
)
data_gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(data_gen)

class FarmerAgent(Agent):  # Eredita da mesa.Agent
    def __init__(self, unique_id, model, income, digital_lit):
        super().__init__(unique_id, model)
        self.income = income
        self.digital_lit = digital_lit
        self.nft_adopted = False
        
    def step(self):
        if not self.nft_adopted:
            adoption_prob = 0.1 + 0.5*(self.income > 1500) + 0.3*self.digital_lit
            if random.random() < adoption_prob:
                self.nft_adopted = True

class RuralModel(Model):
    def __init__(self, farmers):
        self.grid = MultiGrid(20, 20, True)
        self.schedule = RandomActivation(self)
        self.dc = DataCollector(
            model_reporters={"adoption": lambda m: sum(a.nft_adopted for a in m.schedule.agents)/len(m.schedule.agents)}
        )
        
        # Posizionamento agenti
        for idx, farmer in farmers.iterrows():
            agent = FarmerAgent(idx, self, farmer['income'], farmer['digital_lit'])
            try:
                x, y = int(farmer.geometry.x), int(farmer.geometry.y)
                self.grid.place_agent(agent, (x % 20, y % 20))  # Adatta alla griglia
                self.schedule.add(agent)
            except AttributeError:
                continue

    def step(self):
        self.schedule.step()
        self.dc.collect(self)

def run_abm_simulation(config_path):
    # Carica configurazione
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Genera dati agricoltori
    farmers = data_gen.generate_farmers(config)
    
    # Esegui simulazione
    model = RuralModel(farmers)
    for _ in range(10):
        model.step()
    
    # Salva risultati
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'metrics')
    os.makedirs(output_dir, exist_ok=True)
    
    results = model.dc.get_model_vars_dataframe()
    results.to_csv(os.path.join(output_dir, 'adoption_rate.csv'), index=False)
    print(f"Risultati salvati in {output_dir}/adoption_rate.csv")

if __name__ == "__main__":
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'model_params.yml')
    run_abm_simulation(config_path)