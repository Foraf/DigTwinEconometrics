import yaml
import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import os
from faker import Faker

def generate_farmers(config):
    """Generate synthetic farmer data with fallback to random locations"""
    np.random.seed(config['seed'])
    
    # Generate random locations if none specified
    if 'farm_locations' not in config or not config['farm_locations']:
        print("No farm_locations in config - generating random locations in Lika-Senj")
        n = config['n_farmers']
        # Approximate bounding box for Lika-Senj County
        lons = np.random.uniform(15.0, 16.0, n)  # Longitude range
        lats = np.random.uniform(44.0, 45.0, n)   # Latitude range
        locations = list(zip(lons, lats))
    else:
        locations = config['farm_locations']
    
    return gpd.GeoDataFrame({
        'geometry': [Point(float(x), float(y)) for x, y in locations],
        'income': np.random.lognormal(7, 0.3, config['n_farmers']).clip(800, 3000),  # EUR/month range
        'digital_lit': np.random.beta(2, 3, config['n_farmers']),  # 0-1 scale
        'broadband': np.random.random(config['n_farmers']) > 0.3  # 70% have access
    })

def ensure_dir(path):
    """Ensure directory exists"""
    os.makedirs(path, exist_ok=True)

def main():
    # Load config - using absolute path to avoid confusion
    config_path = r'[insert your path]\framework\config\model_params.yml'
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Generate data
    farmers = generate_farmers(config)
    
    # Ensure output directory exists
    output_dir = r'[insert your path]\framework\data\synthetic'
    ensure_dir(output_dir)
    
    # Save with better file handling
    output_path = os.path.join(output_dir, 'farmers.geojson')
    farmers.to_file(output_path, driver='GeoJSON')
    print(f"Successfully saved {len(farmers)} farmers to {output_path}")

if __name__ == "__main__":
    main()