# scripts/04_geospatial_opt.py
import numpy as np
import osmnx as ox
import pandas as pd
from scipy.spatial import distance_matrix
from pulp import LpProblem, LpMinimize, LpVariable, lpSum, PULP_CBC_CMD
import os
from pathlib import Path
import logging
import time
import matplotlib.pyplot as plt
import random

# Configurazione
ox.settings.timeout = 300
ox.settings.use_cache = True
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def correct_p_median(G, max_kiosks=5, sample_size=200):
    """Implementazione corretta del modello p-median"""
    try:
        # 1. Selezione nodi
        nodes = list(G.nodes(data=True))
        if len(nodes) > sample_size:
            nodes = random.sample(nodes, sample_size)
        
        # 2. Matrice distanze
        logger.info("Calcolo distanze tra %d nodi...", len(nodes))
        coords = np.array([(n[1]['x'], n[1]['y']) for n in nodes])
        dist_matrix = distance_matrix(coords, coords)

        # 3. Modello p-median
        logger.info("Configurazione modello p-median...")
        prob = LpProblem("AR_Kiosk_Placement", LpMinimize)
        
        # Variabili
        x = LpVariable.dicts("x", [n[0] for n in nodes], cat='Binary')  # Nodi selezionati
        y = LpVariable.dicts("y", 
                           [(n[0], m[0]) for n in nodes for m in nodes],
                           cat='Binary')  # Assegnazioni
        
        # Funzione obiettivo: minimizza la distanza totale
        prob += lpSum(
            dist_matrix[i][j] * y[(nodes[i][0], nodes[j][0])]
            for i in range(len(nodes))
            for j in range(len(nodes))
        )
        
        # Vincoli:
        # 1. Massimo k chioschi
        prob += lpSum(x.values()) <= max_kiosks
        
        # 2. Ogni nodo assegnato a esattamente un chiosco
        for j in range(len(nodes)):
            prob += lpSum(y[(nodes[i][0], nodes[j][0])] for i in range(len(nodes))) == 1
        
        # 3. Un nodo può essere assegnato solo a chioschi aperti
        for i in range(len(nodes)):
            for j in range(len(nodes)):
                prob += y[(nodes[i][0], nodes[j][0])] <= x[nodes[i][0]]

        # 4. Risolutore configurato
        solver = PULP_CBC_CMD(
            msg=True,
            timeLimit=120,
            options=['presolve on', 'heur on', 'cuts on']
        )

        logger.info("Ottimizzazione in corso...")
        start = time.time()
        prob.solve(solver)
        
        selected = [n[0] for n in nodes if x[n[0]].varValue > 0.9]
        logger.info(f"Selezionati {len(selected)} chioschi in {time.time()-start:.1f}s")
        return selected

    except Exception as e:
        logger.error(f"Errore ottimizzazione: {str(e)}")
        return None

if __name__ == "__main__":
    try:
        # Configurazione
        place = "Otočac, Croatia"
        max_kiosks = 2  # Numero di chioschi desiderato
        project_root = Path(__file__).parent.parent
        output_dir = project_root / "outputs" / "geospatial"
        os.makedirs(output_dir, exist_ok=True)

        # 1. Caricamento rete stradale
        graph_file = output_dir / f"{place.replace(' ', '_')}_network.graphml"
        if os.path.exists(graph_file):
            G = ox.load_graphml(graph_file)
        else:
            G = ox.graph_from_place(place, network_type='drive')
            ox.save_graphml(G, graph_file)

        # 2. Ottimizzazione
        start_time = time.time()
        selected_nodes = correct_p_median(G, max_kiosks=max_kiosks)
        
        if not selected_nodes:
            raise ValueError("Aggiustare i parametri (ridurre max_kiosks o aumentare sample_size)")
        
        logger.info(f"TEMPO TOTALE: {time.time()-start_time:.2f}s")

        # 3. Salvataggio risultati
        df = pd.DataFrame([{
            'node_id': n,
            'x': G.nodes[n]['x'],
            'y': G.nodes[n]['y'],
            'osmid': G.nodes[n].get('osmid', n)  # Se non esiste, usa l'ID del nodo (n)
        } for n in selected_nodes])
        
        csv_path = output_dir / "optimal_kiosks.csv"
        df.to_csv(csv_path, index=False)
        logger.info(f"Risultati salvati in {csv_path}")

        # 4. Visualizzazione
        fig, ax = ox.plot_graph(G, node_size=0, show=False)
        ax.scatter(df['x'], df['y'], c='red', s=100, marker='s')
        img_path = output_dir / "kiosk_map.png"
        plt.savefig(img_path, dpi=150, bbox_inches='tight')
        plt.close()
        logger.info(f"Mappa generata in {img_path}")

    except Exception as e:
        logger.error(f"ERRORE FINALE: {str(e)}")