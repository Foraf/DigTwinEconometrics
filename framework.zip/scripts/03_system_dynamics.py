# scripts/03_system_dynamics.py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import yaml
from scipy.integrate import odeint
from pathlib import Path

def economic_feedback(y, t, alpha, beta):
    """Equazioni differenziali per il modello macroeconomico"""
    gdp, tourism = y
    dgdp = alpha * tourism - 0.05 * gdp
    dtourism = beta * (100 - tourism)
    return [dgdp, dtourism]

def run_macro_model(config, output_dir):
    """Esegue la simulazione e genera il grafico"""
    # Simulazione
    t = np.linspace(0, config['time_horizon'], 100)
    solution = odeint(economic_feedback,
                     [config['initial_gdp'], config['initial_tourism']],
                     t,
                     args=(config['alpha'], config['beta']))  # Args come parametri separati
    
    # Creazione DataFrame
    results = pd.DataFrame(solution, columns=['GDP', 'Tourism'])
    results['Time'] = t
    
    # Creazione grafico
    plt.figure(figsize=(10, 6))
    plt.plot(results['Time'], results['GDP'], 'b-', label='GDP (milioni €)')
    plt.plot(results['Time'], results['Tourism'], 'r--', label='Turismo (migliaia)')
    plt.xlabel('Anni')
    plt.ylabel('Valore')
    plt.title('Andamento macroeconomico\nLika-Senj County')
    plt.legend()
    plt.grid(True)
    
    # Salvataggio
    vis_dir = output_dir / "visualizations"
    os.makedirs(vis_dir, exist_ok=True)
    plt.savefig(vis_dir / "gdp_trend.png", dpi=300, bbox_inches='tight')
    plt.close()
    
    return results

if __name__ == "__main__":
    # Configurazione percorsi
    project_root = Path(__file__).parent.parent
    config_path = project_root / "config" / "model_params.yml"
    output_dir = project_root / "outputs"
    
    # Carica configurazione
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Esegui simulazione
    results = run_macro_model(config, output_dir)
    
    # Salva risultati
    metrics_dir = output_dir / "metrics"
    os.makedirs(metrics_dir, exist_ok=True)
    results.to_csv(metrics_dir / "macro_results.csv", index=False)
    
    print(f"Simulazione completata. Risultati salvati in: {output_dir}")